<div style="margin: 30px auto; text-align: center;">
	<?php echo 'Copyright ©<a target="_blank" href="https://www.taozhuti.cn/" rel="nodofollow">TaoZhuTi.Cn</a> 2023' ?>
</div>
<script>
	
	$(".layui-nav li a").each(function() {
		if(this.href==document.location.toString().split("#")[0]){$(this).parent("li").addClass("layui-this");return false;}
	});

	$('.arrange').arrangeable();
	
</script>