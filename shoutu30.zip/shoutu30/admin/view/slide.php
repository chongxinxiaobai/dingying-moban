<?php 
	require('./config.php');
	$data = $config['slide'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>后台管理中心</title>
<?php require('header.php'); ?>
</head>
	<body>
		<div class="page-container">
			<?php require('top.php');?>
			<ul class="layui-nav">
				<?php config_menu($config) ?>
			</ul>
			<div class="layui-tab-content">
				<blockquote class="layui-elem-quote layui-text">
  					建议填写视频id，因为部分样式需要获取视频的海报及标题等参数，附加参数填写背景颜色值，格式#000000，可选填。
				</blockquote>
				<form class="layui-form" method="post" action="?url=slide&array=slide&type=add" enctype="multipart/form-data">
					<?php config_img_post('1');?>
				</form>
				<form class="layui-form" method="post" action="?url=slide&array=slide&type=post" enctype="multipart/form-data">					
					<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
						<legend>已添加的列表组 - 支持拖拽排序哦！</legend>
					</fieldset>
					<?php
						if(is_array($data['data'])){
							$href = '?url=slide&array=slide&';
							config_img('1',$data['data'],$href);
						}
					?>
					<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
						<legend>参数设置</legend>
					</fieldset>
					<div class="layui-form-item">
						<div class="layui-inline">
							<label class="layui-form-label">启用幻灯</label>
							<div class="layui-input-inline">
								<input type="hidden" name="is" value="0">
								<input type="checkbox" lay-skin="switch" name="is" value="1"<?php if($data['is']) { echo "checked"; }?>>
							</div>
						</div>
						<div class="layui-inline">
							<label class="layui-form-label">选择样式</label>
							<div class="layui-input-inline">
								<select name="style">
									<option value="0"<?php if($data['style']=='0') { echo "selected"; }?>>底部缩略图版</option>
									<option value="1"<?php if($data['style']=='1') { echo "selected"; }?>>右侧文字列表版</option>
									<option value="2"<?php if($data['style']=='2') { echo "selected"; }?>>小海报切换版</option>
								</select>
							</div>
						</div>
					</div>					
					<div class="layui-form-item" style="padding-top: 20px; text-align: center;">
						<button type="submit" class="layui-btn layui-btn-normal"> <i class="layui-icon layui-icon-release"></i> 确认保存</button>
						<button type="button" class="layui-btn layui-btn-danger layer-confirm" data-url="?url=slide&array=slide&type=empty" data-msg="您确定要进行清空设置吗？该操作不可撤销！">
							<i class="layui-icon layui-icon-delete"></i> 清空模块
						</button>
						<a href="/" target="_back" class="layui-btn layui-btn-primary"> <i class="layui-icon layui-icon-home"></i> 打开前台</a>
					</div>
				</form>
				
			</div>
		</div>
		<?php require('footer.php'); ?>
	</body>
</html>

