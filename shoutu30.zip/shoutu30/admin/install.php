<?php
return array (
  'set' => 
  array (
    'notice' => '欢迎光临本站，本站域名ahlly.com',
    'notice_is' => '0',
    'seahot' => '流浪地球2,狂飙,乡村爱情15,速度与激情,汪汪立功队 第六季',
    'seahot_is' => '1',
    'linkurl' => '#',
    'linkurl_is' => '1',
    'topadjs' => '',
    'footadjs' => '',
    'footcode' => '',
  ),
  'basic' => 
  array (
    'color' => '#f84d3a',
    'static' => '',
    'substatic' => '',
    'logo' => 'https://www.ahlly.com/upload/site/20231007-1/cfef2979050199f821121893b0cf97e4.png',
    'favicon' => 'https://www.ahlly.com/upload/site/20231007-1/a7c76afc658a06d83bf4471e517dc7ee.png',
    'foottips' => '本站所有视频和图片均来自互联网收集而来，版权归原创者所有，本网站只提供web页面服务，并不提供资源存储，也不参与录制、上传。',
    'foottips_is' => '1',
    'jscode' => '',
  ),
  'poster' => 
  array (
    'lopimg' => '/template/shoutu30/img/load.png',
    'high' => '140',
    'subtitle' => 'vod_remarks',
    'subtitle_is' => '1',
    'text' => 'vod_remarks',
    'position' => 'center',
    'text_is' => '0',
    'radius' => '10',
  ),
  'other' => 
  array (
    'cloredark' => 'dark',
    'type' => '1',
    'class' => '1',
    'area' => '1',
    'star' => '0',
    'director' => '0',
    'year' => '1',
    'lang' => '1',
    'letter' => '0',
    'reload' => '1',
    'next' => '1',
    'favorite' => '0',
    'comment' => '1',
    'support' => '1',
    'qrcode' => '1',
    'copy' => '1',
    'error' => '1',
    'less' => '0',
    'modeno' => '1',
    'rightno' => '0',
    'f12no' => '1',
    'iframeno' => '0',
    'selectno' => '0',
    'rightnotext' => '你知道的太多了！',
    'opgreytime' => '2023-04-05',
    'opgrey' => '1',
    'cody' => '0',
    'codyright' => '0',
  ),
  'slide' => 
  array (
    'data' => 
    array (
      0 => 
      array (
        'is' => '1',
        'title' => '测试1',
        'id' => '11539',
        'url' => 'https://ahlly.com/',
        'img' => 'https://www.ahlly.com/upload/site/20231007-1/cfef2979050199f821121893b0cf97e4.png',
        'val' => '',
        'blank' => '0',
      ),
      2 => 
      array (
        'is' => '1',
        'title' => '测试2',
        'id' => '6387',
        'url' => 'https://ahlly.com/',
        'img' => 'https://www.ahlly.com/upload/site/20231007-1/cfef2979050199f821121893b0cf97e4.png',
        'val' => '',
        'blank' => '0',
      ),
      1 => 
      array (
        'is' => '1',
        'title' => '测试3',
        'id' => '8543',
        'url' => 'https://ahlly.com/',
        'img' => 'https://www.ahlly.com/upload/site/20231007-1/cfef2979050199f821121893b0cf97e4.png',
        'val' => '',
        'blank' => '0',
      ),
      3 => 
      array (
        'is' => '1',
        'title' => '测试4',
        'id' => '1627',
        'url' => 'https://ahlly.com/',
        'img' => 'https://www.ahlly.com/upload/site/20231007-1/cfef2979050199f821121893b0cf97e4.png',
        'val' => '',
        'blank' => '0',
      ),
      4 => 
      array (
        'is' => '1',
        'title' => '测试5',
        'id' => '13467',
        'url' => 'https://ahlly.com/',
        'img' => 'https://www.ahlly.com/upload/site/20231007-1/cfef2979050199f821121893b0cf97e4.png',
        'val' => '',
        'blank' => '0',
      ),
    ),
    'is' => '1',
    'style' => '0',
  ),
  'nav' => 
  array (
    'data' => 
    array (
      0 => 
      array (
        'is' => '1',
        'icon' => 'icon-home',
        'title' => '首页',
        'type' => 'web',
        'val' => '/',
        'blank' => '0',
      ),
      1 => 
      array (
        'is' => '1',
        'icon' => 'icon-film',
        'title' => '电影',
        'type' => '1',
        'val' => '1',
        'blank' => '0',
      ),
      8 => 
      array (
        'is' => '1',
        'icon' => '',
        'title' => '动作片',
        'type' => '1',
        'val' => '6',
        'blank' => '0',
      ),
      9 => 
      array (
        'is' => '1',
        'icon' => '',
        'title' => '恐怖片',
        'type' => '1',
        'val' => '9',
        'blank' => '0',
      ),
      2 => 
      array (
        'is' => '1',
        'icon' => 'icon-video',
        'title' => '电视剧',
        'type' => '1',
        'val' => '2',
        'blank' => '0',
      ),
      10 => 
      array (
        'is' => '1',
        'icon' => '',
        'title' => '美剧',
        'type' => '1',
        'val' => '15',
        'blank' => '0',
      ),
      3 => 
      array (
        'is' => '1',
        'icon' => 'icon-music',
        'title' => '综艺',
        'type' => '1',
        'val' => '3',
        'blank' => '0',
      ),
      4 => 
      array (
        'is' => '1',
        'icon' => 'icon-pop',
        'title' => '动漫',
        'type' => '1',
        'val' => '4',
        'blank' => '0',
      ),
      5 => 
      array (
        'is' => '0',
        'icon' => 'icon-list',
        'title' => '资讯',
        'type' => '2',
        'val' => '5',
        'blank' => '0',
      ),
      6 => 
      array (
        'is' => '0',
        'icon' => 'icon-favorite',
        'title' => '专题',
        'type' => 'url',
        'val' => 'topic/index',
        'blank' => '0',
      ),
      7 => 
      array (
        'is' => '1',
        'icon' => 'icon-rank',
        'title' => '热播榜',
        'type' => 'url',
        'val' => 'label/hot',
        'blank' => '0',
      ),
    ),
  ),
  'index' => 
  array (
    'data' => 
    array (
      5 => 
      array (
        'is' => '1',
        'title' => '最近热播',
        'block' => 'vod_list',
        'type' => 'all',
        'by' => 'hits',
        'subval' => '',
      ),
      0 => 
      array (
        'is' => '1',
        'title' => '推荐分类',
        'block' => 'vod_type',
        'type' => '1,2,3,4,6,7,8,9,10,11,12',
        'by' => 'time',
        'subval' => '',
      ),
      13 => 
      array (
        'is' => '1',
        'title' => '最新',
        'block' => 'vod_list2',
        'type' => '1,2,3,4',
        'by' => 'time',
        'subval' => '',
      ),
      10 => 
      array (
        'is' => '1',
        'title' => '1号广告',
        'block' => 'vod_ad',
        'type' => '1',
        'by' => 'time',
        'subval' => '',
      ),
      12 => 
      array (
        'is' => '1',
        'title' => '排行榜列表',
        'block' => 'vod_rank',
        'type' => '1,2,3,4,6,7',
        'by' => 'time',
        'subval' => '',
      ),
      8 => 
      array (
        'is' => '1',
        'title' => '随机推荐',
        'block' => 'vod_text',
        'type' => '1,2,3,4',
        'by' => 'rnd',
        'subval' => '',
      ),
    ),
  ),
  'navright' => 
  array (
    'data' => 
    array (
      0 => 
      array (
        'is' => '1',
        'icon' => 'icon-moon skin',
        'title' => '夜间模式',
        'type' => 'web',
        'val' => 'javascript:shoutu_skin();',
        'blank' => '0',
      ),
      1 => 
      array (
        'is' => '1',
        'icon' => 'icon-time',
        'title' => '播放记录',
        'type' => 'web',
        'val' => 'javascript:shoutu_dialog(\'History\');',
        'blank' => '0',
      ),
      2 => 
      array (
        'is' => '1',
        'icon' => 'icon-hot',
        'title' => '热播榜',
        'type' => 'url',
        'val' => 'label/hot',
        'blank' => '0',
      ),
    ),
  ),
  'navfoot' => 
  array (
    'data' => 
    array (
      0 => 
      array (
        'is' => '1',
        'icon' => '',
        'title' => '网站地图',
        'type' => 'url',
        'val' => 'map/index',
        'blank' => '0',
      ),
      1 => 
      array (
        'is' => '1',
        'icon' => '',
        'title' => 'RSS订阅',
        'type' => 'url',
        'val' => 'rss/index',
        'blank' => '0',
      ),
      2 => 
      array (
        'is' => '1',
        'icon' => '',
        'title' => '百度蜘蛛',
        'type' => 'url',
        'val' => 'rss/baidu',
        'blank' => '0',
      ),
      3 => 
      array (
        'is' => '1',
        'icon' => '',
        'title' => '谷歌蜘蛛',
        'type' => 'url',
        'val' => 'rss/google',
        'blank' => '0',
      ),
      4 => 
      array (
        'is' => '1',
        'icon' => '',
        'title' => '搜狗地图',
        'type' => 'url',
        'val' => 'rss/sogou',
        'blank' => '0',
      ),
    ),
  ),
  'navbottom' => 
  array (
    'data' => 
    array (
      0 => 
      array (
        'is' => '1',
        'icon' => 'icon-edit1',
        'title' => '留言板',
        'type' => 'url',
        'val' => 'gbook/index',
        'blank' => '0',
      ),
      1 => 
      array (
        'is' => '1',
        'icon' => 'icon-service',
        'title' => '联系客服',
        'type' => 'web',
        'val' => 'javascript:shoutu_dialog(\'Weixin\');',
        'blank' => '0',
      ),
      2 => 
      array (
        'is' => '1',
        'icon' => 'icon-home',
        'title' => '返回首页',
        'type' => 'web',
        'val' => '/',
        'blank' => '0',
      ),
      3 => 
      array (
        'is' => '1',
        'icon' => 'icon-moon skin',
        'title' => '深色模式',
        'type' => 'web',
        'val' => 'javascript:shoutu_skin();',
        'blank' => '0',
      ),
    ),
  ),
  'dialog' => 
  array (
    'data' => 
    array (
      0 => 
      array (
        'is' => '1',
        'id' => 'Weixin',
        'title' => '联系客服',
        'class' => 'center',
        'code' => '<div class="text-center"><p><img src="/template/shoutu30/img/weixin.jpg" /></p><p>微信扫一扫联系我们</p></div>',
      ),
    ),
  ),
  'poster2' => 
  array (
    'lopimg' => '/template/shoutu30/img/load2.png',
    'high' => '60',
    'subtitle' => 'vod_remarks',
    'subtitle_is' => '1',
    'text' => 'vod_area',
    'position' => '',
    'text_is' => '0',
  ),
  'textlist' => 
  array (
    'subtitle' => 'vod_remarks',
  ),
  'typeid' => 
  array (
    'data' => 
    array (
      0 => 
      array (
        'title' => '电影',
        'id' => '1',
      ),
      1 => 
      array (
        'title' => '电视剧',
        'id' => '2',
      ),
    ),
  ),
  'type1' => 
  array (
    'data' => 
    array (
      0 => 
      array (
        'is' => '1',
        'title' => '最近更新',
        'block' => 'vod_list',
        'type' => 'current',
        'by' => 'time',
        'subval' => '',
      ),
      1 => 
      array (
        'is' => '1',
        'title' => '最近热播',
        'block' => 'vod_list',
        'type' => 'current',
        'by' => 'hits',
        'subval' => '',
      ),
      2 => 
      array (
        'is' => '1',
        'title' => '成龙系列',
        'block' => 'vod_list',
        'type' => 'current',
        'by' => 'time',
        'subval' => '',
        'actor' => '成龙',
      ),
      3 => 
      array (
        'is' => '1',
        'title' => '速度与激情系列',
        'block' => 'vod_list',
        'type' => 'current',
        'by' => 'time',
        'subval' => '',
        'name' => '速度与激情',
      ),
    ),
  ),
  'type2' => 
  array (
    'data' => 
    array (
      1 => 
      array (
        'is' => '1',
        'title' => '2022最新剧',
        'block' => 'vod_list',
        'type' => 'current',
        'by' => 'time',
        'subval' => '',
        'year' => '2022',
      ),
      0 => 
      array (
        'is' => '1',
        'title' => '赵丽颖主演剧',
        'block' => 'vod_list',
        'type' => 'current',
        'by' => 'time',
        'subval' => '',
        'actor' => '赵丽颖',
      ),
      2 => 
      array (
        'is' => '1',
        'title' => '刘涛主演热剧',
        'block' => 'vod_list',
        'type' => 'current',
        'by' => 'time',
        'subval' => '',
        'actor' => '刘涛',
      ),
      3 => 
      array (
        'is' => '1',
        'title' => '热播美剧',
        'block' => 'vod_list',
        'type' => '15',
        'by' => 'hits',
        'subval' => '',
      ),
    ),
  ),
  'play' => 
  array (
    'data' => 
    array (
      0 => 
      array (
        'is' => '1',
        'title' => '同主演推荐',
        'block' => 'vod_list',
        'type' => 'current',
        'by' => 'time',
        'subval' => '',
        'actor' => 'current',
        'year' => '2022',
      ),
      1 => 
      array (
        'is' => '1',
        'title' => '同年代推荐',
        'block' => 'vod_list',
        'type' => 'current',
        'by' => 'time',
        'subval' => '',
        'year' => 'current',
      ),
      2 => 
      array (
        'is' => '1',
        'title' => '同类型推荐',
        'block' => 'vod_list',
        'type' => 'current',
        'subval' => '',
        'by' => 'hits',
      ),
    ),
  ),
  'ad' => 
  array (
    'data' => 
    array (
      1 => 
      array (
        'is' => '1',
        'title' => '首页1号',
        'url' => 'https://ahlly.com/',
        'img' => 'https://m.ykimg.com/material/0A03/A1/202212/1221/3082837/1671604679858/0D01000063A2AAE50742279232473155.jpg',
        'blank' => '0',
      ),
    ),
  ),
  'seo1' => 
  array (
    'title' => '[site_name]',
    'key' => '[site_keywords]',
    'des' => '[site_description]',
  ),
  'seo0' => 
  array (
    'title' => '[site_name]',
    'key' => '[site_keywords]',
    'des' => '[site_description]',
  ),
  'seo10' => 
  array (
    'title' => '视频首页-[site_name]',
    'key' => '[site_keywords]',
    'des' => '[site_description]',
  ),
  'seo14' => 
  array (
    'title' => '[vod_name]-在线观看-[vod_area][vod_year][vod_class]片-[site_name]',
    'key' => '[site_keywords],[vod_class]',
    'des' => '[vod_blurb]',
  ),
  'seo15' => 
  array (
    'title' => '[vod_name]-在线观看在线下载-[vod_area][vod_year][vod_class]片-[site_name]',
    'key' => '[site_keywords],[vod_class]',
    'des' => '[vod_blurb]',
  ),
  'seo11' => 
  array (
    'title' => '[type_name]-[site_name]',
    'key' => '[site_keywords]',
    'des' => '[site_description]',
  ),
  'seo30' => 
  array (
    'title' => '专题首页-[site_name]',
    'key' => '[site_keywords]',
    'des' => '[site_description]',
  ),
  'seo12' => 
  array (
    'title' => '[type_name]-[site_name]',
    'key' => '[site_keywords]',
    'des' => '[site_description]',
  ),
  'seo13' => 
  array (
    'title' => '搜索结果-[site_name]',
    'key' => '[site_keywords]',
    'des' => '[site_description]',
  ),
  'seo31' => 
  array (
    'title' => '[topic_name]-[site_name]',
    'key' => '[site_keywords]',
    'des' => '[topic_blurb]',
  ),
  'seo2' => 
  array (
    'title' => '网站地图-[site_name]',
    'key' => '[site_keywords]',
    'des' => '[site_description]',
  ),
  'seo4' => 
  array (
    'title' => '留言板-[site_name]',
    'key' => '[site_keywords]',
    'des' => '[site_description]',
  ),
);