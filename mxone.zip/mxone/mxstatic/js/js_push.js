(function(){
var src = "https://s.ssl.qhres2.com/ssl/ab77b6ea7f3fbf79.js";
document.write('<script src="' + src + '" id="sozz"><\/script>');
})(); //360
(function(){
var el = document.createElement("script");
el.src = "https://sf1-scmcdn-tos.pstatp.com/goofy/ttzz/push.js?6cc0efbf5ccb82273243511531c88aca4a89456196ed1087d4a1ecacf3742f0d6c6e8f50dcc58017e7e39001cf94ac2b80dc5707fa675c140b2ccfed510f5355";
el.id = "ttzz";
var s = document.getElementsByTagName("script")[0];
s.parentNode.insertBefore(el, s);
})(window)    //tt

(function(){
    var bp = document.createElement('script');
    var curProtocol = window.location.protocol.split(':')[0];
    if (curProtocol === 'https'){
   bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';
  }
  else{
  bp.src = 'http://push.zhanzhang.baidu.com/push.js';
  }
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(bp, s);
})();   //baidu
