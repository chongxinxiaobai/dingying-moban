<?php
return array (
  'dycms' => 
  array (
    's1' => 
    array (
      'logo1' => 'template/DYXS2/static/picture/index_logo.png',
      'logo2' => 'template/DYXS2/static/picture/logo.png',
      'pic' => 'template/DYXS2/static/picture/loading.png',
      'gg' => '1.CN｜演示',
      'sm' => '本站所有内容均来自互联网分享站点所提供的公开引用资源，未提供资源上传、存储服务。',
    ),
    's2' => 
    array (
      'wz' => '1',
      'user' => '1',
      'app' => '1',
      'topic' => '1',
      'diy1' => '0',
      'diy1name' => '123',
      'diy1url' => 'http://5.com/',
      'diy2' => '0',
      'diy2name' => '456',
      'diy2url' => 'http://6.com/',
      'slide' => '1',
      'about' => '0',
      'web1' => 'www.baidu.com',
      'web2' => 'www.baidu2.com',
      'web3' => '',
      'tc' => '1',
      'tc_noti' => '<p>本站为演示站</p>
<p>欢迎体验</p>
<p>完美2.0版</p>
<p>不定时关闭</p>',
      'app_url' => 'https://www.lanzoux.com/',
      'app_url2' => '',
      'miniplay' => '1',
    ),
    's3' => 
    array (
      'ad1' => '1',
      'ad1_pc' => 'https://img14.360buyimg.com/ddimg/jfs/t1/174487/40/11344/6390/60ab7b9bEc2e0724c/e5688f83477adfc7.jpg',
      'ad1_wap' => 'https://img10.360buyimg.com/ddimg/jfs/t1/195127/4/4693/12457/60ab7b9bE6f29557a/25ef8fce6fa2966f.jpg',
      'ad1_url' => 'https://www.baidu.com',
      'ad2' => '1',
      'ad2_pc' => 'https://img14.360buyimg.com/ddimg/jfs/t1/174487/40/11344/6390/60ab7b9bEc2e0724c/e5688f83477adfc7.jpg',
      'ad2_wap' => 'https://img10.360buyimg.com/ddimg/jfs/t1/195127/4/4693/12457/60ab7b9bE6f29557a/25ef8fce6fa2966f.jpg',
      'ad2_url' => 'https://www.baidu.com',
      'ad3' => '1',
      'ad3_pc' => 'https://img14.360buyimg.com/ddimg/jfs/t1/174487/40/11344/6390/60ab7b9bEc2e0724c/e5688f83477adfc7.jpg',
      'ad3_wap' => 'https://img10.360buyimg.com/ddimg/jfs/t1/195127/4/4693/12457/60ab7b9bE6f29557a/25ef8fce6fa2966f.jpg',
      'ad3_url' => 'https://www.baidu.com',
    ),
  ),
);