<?php
require ('create.php');
loadhead('免费VIP视频解析');
loadmian('请填写视频地址');
loadfoot();
?>