var ShouTu = {
	'Url': document.URL,
    'Title': document.title,
	'Browser': {
		url: document.URL,
		domain: document.domain,
		title: document.title,
		language: (navigator.browserLanguage || navigator.language).toLowerCase(),
		canvas: function() {
			return !!document.createElement("canvas").getContext
		}(),
		useragent: function() {
			var a = navigator.userAgent;
			return {
				mobile: !! a.match(/AppleWebKit.*Mobile.*/),
				ios: !! a.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/),
				android: -1 < a.indexOf("Android") || -1 < a.indexOf("Linux"),
				iPhone: -1 < a.indexOf("iPhone") || -1 < a.indexOf("Mac"),
				iPad: -1 < a.indexOf("iPad"),
				trident: -1 < a.indexOf("Trident"),
				presto: -1 < a.indexOf("Presto"),
				webKit: -1 < a.indexOf("AppleWebKit"),
				gecko: -1 < a.indexOf("Gecko") && -1 == a.indexOf("KHTML"),
				weixin: -1 < a.indexOf("MicroMessenger")
			}
		}()
	},
	'Cookie': {
		'Set':function(name,value,days){
	        var expires;
	        if (days) {
	            expires = days;
	        } else{
	            expires = "";
	        }
	        $.cookie(name,value,{expires:expires,path:'/'});
		},
		'Get':function(name){
			var styles = $.cookie(name);
		    return styles;
		},
		'Del':function(name,tips){
			if(window.confirm(tips)){
	            $.cookie(name,null,{expires:-1,path: '/'});
	            location.reload();
	       	}else{
	            return false;
	        }
		}
	},
	'Ajax':function(url,type,dataType,data,sfun,efun,cfun){
        type=type||'get';
        dataType=dataType||'json';
        data=data||'';
        efun=efun||'';
        cfun=cfun||'';
        $.ajax({
            url:url,
            type:type,
            dataType:dataType,
            data:data,
            timeout: 5000,
            beforeSend:function(XHR){
            },
            error:function(XHR,textStatus,errorThrown){
                if(efun) efun(XHR,textStatus,errorThrown);
            },
            success:function(data){
                sfun(data);
            },
            complete:function(XHR, TS){
                if(cfun) cfun(XHR, TS);
            }
        })
    },
	'Swiper': {
		'Slide': {
			'Init': function() {
				$(".slide-swiper").each(function(){
					let $that = $(this);
					ShouTu.Swiper.Slide.Set(this,$that.attr('data-effect'),$that.attr('data-play'),$that.attr('data-direction'));
				});
			},
			'Set': function(id,effect,play,direction) {
				effect=effect||'fade';
				play=play||3000;
				direction=direction||'horizontal';
				var Slide = new Swiper(id, {
					parallax: true,
					effect: effect,
					pauseOnMouseEnter: true,
					autoHeight: true,
					fadeEffect: {
						crossFade: true,
					},
					pagination: {
						el: ".swiper-pagination",
						clickable: true,
					},
					navigation: {
						nextEl: ".swiper-button-next",
						prevEl: ".swiper-button-prev",
					},
					autoplay: {
						delay: play,
					},
					thumbs: {
						swiper: {
						  el: '.slide-swiper-btn',
						  slidesPerView: 'auto',
						  watchSlidesVisibility: true,
						  direction: ''+direction,
						  pagination: {
							el: ".swiper-pagination",
							clickable: true,
							},
							navigation: {
								nextEl: ".swiper-button-next",
								prevEl: ".swiper-button-prev",
							},
						  on:{
							init: function(swiper){
								let $width = $(document).width();
								if($width>960){
									$('.swiper-mouseover .swiper-slide').on('mouseover', function () {
										Slide.slideTo($(this).index());
									});
								}
							}
						}				 
						},
					}
				});
				
			}
		},
		'Center': {
			'Init': function() {
				$(".slide-center").each(function(){
					var $that = $(this);
					ShouTu.Swiper.Center.Set(this,$that.attr('data-max'),$that.attr('data-min'),$that.attr('data-margins'));
				});
			},
			'Set': function(id,max,min,margins) {
				margins=margins||20;
				var Center = new Swiper(id, {
					slidesPerView: max,
					spaceBetween: margins,
					centeredSlides: true,
					loop: true,
					autoplay:true,
					pagination: {
						el: '.swiper-pagination',
						clickable: true,
					},
					navigation: {
						nextEl: ".swiper-button-next",
						prevEl: ".swiper-button-prev",
					},
					breakpoints: {
						320: {
							slidesPerView: min,
							spaceBetween: 0,
						},
						1200: {
							slidesPerView: max,
							spaceBetween: margins,
						},
					},
				});
			}
		},
		'Left': {
			'Init': function() {
				$(".slide-left").each(function(){
					var $that = $(this);
					ShouTu.Swiper.Left.Set(this,$that.attr('data-xxl'),$that.attr('data-xl'),$that.attr('data-lg'),$that.attr('data-md'),$that.attr('data-sm'),$that.attr('data-xs'),$that.attr('data-row'),$that.attr('data-id'));
				});
			},
			'Set': function(id,xxl,xl,lg,md,sm,xs,row,ids) {
				var Left = new Swiper(id, {
					loop: false,
					slideToClickedSlide: true,
					grid: {
						fill: 'row',
						rows: row,
					},
					pagination: {
						el: '.lef-page'+ids,
						type: 'fraction',
						renderFraction: function (currentClass, totalClass) {
						  return '<span class="' + currentClass + '"></span>' + ' / ' + '<span class="' + totalClass + '"></span>';
						},
				  	},
					navigation: {
						nextEl: ".right-next"+ids,
						prevEl: ".left-prev"+ids,
					},
					breakpoints: {
						320: {
							slidesPerView: xs,
							grid: {
								fill: 'row',
								rows: 2,
							},
						},
						768: {
							slidesPerView: sm,
							grid: {
								fill: 'row',
								rows: 2,
							},
						},
						960: {
							slidesPerView: md,
						},
						1200: {
							slidesPerView: lg,
						},
						1400: {
							slidesPerView: xl,
						},
						1600: {
							slidesPerView: xxl,
						},
					},
				});
			}
		},
		'Left2': {
			'Init': function() {
				$(".slide-left2").each(function(){
					var $that = $(this);
					ShouTu.Swiper.Left2.Set(this);
				});
			},
			'Set': function(id) {
				var Left2 = new Swiper(id, {
					loop: false,
					slidesPerView: 'auto',
					spaceBetween : 15,
					slideToClickedSlide: true,
					navigation: {
						nextEl: ".swiper-button-next",
						prevEl: ".swiper-button-prev",
					},
				});
			}
		},
		'Nav': function() {
			var Nav = new Swiper('.slide-nav',{
				slidesPerView:'auto', 
				hashNavigation: true,
				preventClicks: false,
				slideToClickedSlide: true,
				on:{
					init: function(swiper){
						$index = swiper.$el.find('li.active').index()*1;
						if($index > 2){
							$index = $index-1;
						}
						swiper.slideToLoop($index, 1000, false);
					}
				}
			});
		},
	},
	'Images': {
		'Lazyload': function() {
			$(".lazyload").lazyload({
				effect: "fadeIn",
				threshold: 200,
				failure_limit : 10,
				skip_invisible : false
			});
		},
		'Qrcode': {
			'Init': function() {
				if($("#qrcode").length){
					var $that = $("#qrcode");
	                ShouTu.Images.Qrcode.Set($that.attr('data-link'),$that.attr('data-dark'),$that.attr('data-light'));
				}
			},
			'Set':  function(url,dark,light) {
				url=0||location.href;
				var qrcode = new QRCode('qrcode', {
				  	text: url,
				  	width: 120,
				  	height: 120,
				  	colorDark : dark,
				  	colorLight : light,
				  	correctLevel : QRCode.CorrectLevel.H
				});
			}	
		},
	},
	'Link': {
		'Copy': {
			'Init': function() {
				$(".copy-link").each(function(){
					var links = $(this).attr("data-url");
					ShouTu.Link.Copy.Set(this,links);
				});
				$(".copy-html").each(function(){
					var html = $(this).parent().find(".content").html();
					ShouTu.Link.Copy.Set(this,html);
				});
			},
			'Set': function(id,content) {
				var clipboard = new Clipboard(id, {
					text: function() {									
						return content;
					}
				});
				clipboard.on('success', function(e) {
					ShouTu.Other.Toast('复制成功',1,1000);
				});
				clipboard.on("error",function(e){
					ShouTu.Other.Toast('复制失败',0,1000);
				});
			}
			
		}
	},
	'Other': {
		'Nav': function() {
			$('.switch-card').each(function(){
				$(this).find('li').click(function() {
					var $id = $(this).find('a').attr('data-toggle');
					$(this).addClass('active').siblings().removeClass('active');
					$(this).parents(".panel").find('#'+$id).addClass('active').siblings().removeClass('active');
				});
			});
			$(".menu li a").each(function() {
				if(this.href==document.location.toString().split("#")[0]){$(this).parent("li").addClass("active");return false;}
			});
		},
		'Skin': {
			'Init': function() {
				let $theme = ShouTu.Cookie.Get('theme');
				if($theme){
					$('body').attr('shoutu-theme',$theme);
					if($theme=='dark'){
						$('.skin').removeClass('icon-moon').addClass('icon-sun');
					}else{
						$('.skin').removeClass('icon-sun').addClass('icon-moon');
					}
				}
			},
			'Set': function() {
				let $theme = $('body').attr('shoutu-theme');
				ShouTu.Other.Toast('正在切换...',2,1000);
				setTimeout(function () {
					if($theme=='dark'){
						$('body').attr('shoutu-theme','white');
						ShouTu.Cookie.Set('theme','white',365);
						$('.skin').removeClass('icon-sun').addClass('icon-moon');
					}else{
						$('body').attr('shoutu-theme','dark');
						$('.skin').removeClass('icon-moon').addClass('icon-sun');
						ShouTu.Cookie.Set('theme','dark',365);
					}
				}, 1000);
			}
		},
		'Sort': function() {
			$(".sort-button").each(function(){
				$(this).on("click",function(e){
					e.preventDefault();
					$(this).parent().parent().parent().find(".sort-list").each(function(){
					    var playlist=$(this).find("li");
					    for(let i=0,j=playlist.length-1;i<j;){
					        var l=playlist.eq(i).clone(true);
					        var r=playlist.eq(j).replaceWith(l);
					        playlist.eq(i).replaceWith(r);
					        ++i;
					        --j;
					    }
					});
				});
			});
		},
		'Search': function() {	
			$('.OpenSea').on('click', function() {
				let $dialog = $(".search-form");
				$dialog.addClass('show').removeClass('hide').find("input").focus().click;
				$dialog.find(".dropdown-menu").show();
			});
			$('.OnSea').on('click', function() {
				let $dialog = $(".search-form");
				$dialog.addClass('hide').removeClass('show');
				$dialog.find(".dropdown-menu").hide();
			});
		},
		'Collapse': function() {
			$(".text-collapse").each(function(){
				$(this).find(".details").on("click",function(){
					$(this).parent().find(".sketch").addClass("hide");
					$(this).parent().find(".data").css("display","");
					$(this).remove();
				});
			});
			$(".dropdown-hover").click(function(){
				$(this).find(".dropdown-box").toggle();
			});
		},
		'Scroll': function(id) {
			id=id||1;
			if(id=='1'){
				$("html, body").animate({
					scrollTop: 0
				}, 400);
			}else{
				let Position = $("#"+id).position();
				$("html, body").animate({
					scrollTop: Position.top
				}, 500);
			}
			return true;
		},
		'Slidedown': function() {
			let display = $('.slideDown-box');
			$(".slideDown-btn").click(function() {
				
		  		if(display.css('display') == 'block'){
		  			display.slideUp("slow");
		  			$(this).html('展开  <i class="icon icon-down"></i>');
				}else{
					display.slideDown("slow"); 
					$(this).html('收起   <i class="icon icon-up"></i>');
				}
			});
		},
		'Close': function() {
			$(".close-btn").on("click",function(){
				$(this).parents(".close-box").remove();
			});
		},
		'Roll': function(obj,higt,time) {
			setInterval(function(){ 
				$(obj).find("ul").animate({
					marginTop : higt,
				},time,function(){
					$(this).css({marginTop : "0px"}).find("li:first").appendTo(this);
				})
			}, 3000);
		},
		'Dialog': function(id) {
			let $dialog = $("#"+id);
			if($dialog.hasClass('show')){
				$dialog.removeClass('show');
				$('.mask').hide();
			}else{
				$dialog.addClass('show');
				$('.mask').show();
			}
		},
		'Toast': function(msg,state,time) {
			let $toast = $("#Toast");
			if(state=='0'){
				$toast.find('.icon').addClass('icon-error');
			} else if(state=='1'){
				$toast.find('.icon').addClass('icon-yes');
			} else if(state=='2'){
				$toast.find('.icon').addClass('icon-reload loading');
			}
			$toast.fadeIn(100).find('.msg').html(msg);
			setTimeout(function () {
				$toast.fadeOut(100);
			}, time);
		},
		'More': function() {
			$('body').append('<div id="Toast" style="display: none;"><div class="shoutu-toast eject"><i class="icon"></i><p class="msg"></p></div></div><div class="mask" id="mask" style="display: none;"></div>');
			$('.eject-close, .mask').on('click', function() {
				$('.eject').removeClass('show');
				$('.mask').hide();
			});
			var $width = $(document).width();
			if($width>1200){
				$('.OpenMenu').on('click', function() {
					let $dialog = $(".shoutu-leftbar");
					if($dialog.hasClass('hide')){
						$dialog.addClass('show').removeClass('hide');
						$(".page-bd").removeClass('auto');
					}else{
						$dialog.addClass('hide').removeClass('show');;
						$(".page-bd").addClass('auto');
					}
				});
			}else{
				$('.OpenMenu').on('click', function() {
					let $dialog = $(".shoutu-leftbar");
					if($dialog.hasClass('show')){
						$dialog.removeClass('show');
						$('.mask').hide();
					}else{
						$dialog.addClass('show');
						$('.mask').show();
					}
				});
			}
			$(window).scroll(function() {
				500 < $(this).scrollTop() ? $("a.backtop").css("display", "") : $("a.backtop").css("display", "none");
			});
		}
	},
	'Mac': {
		'Paylist': function() {
			var playlist=$(".playlist");
			playlist.each(function(i){
				if($(this).find("li").length>29){
					$(this).find("li").eq(28).after("<li class='more'><a href='javascript:;'> 更多 <i class='icon icon-bottom'></i></a></li>");
					var more=$(this).find("li.more");
	                var prev=more.index();
	                more.show();
	                for(i=prev+1;i<$(this).find("li").length;++i)
	                $(this).find("li").eq(i).hide();
				}else if($(this).find("li").length<5){
					$(this).addClass("nonum")
				}
			})
			$("li.more").on("click",function(){
	            var more=$(this).parent("ul").find("li.more");
	            var newlist=$(this).parent("ul").find("li");
	            var prev=more.index();
	            for(i=0;i<newlist.length;++i)
	                newlist.eq(i).show();
	            more.hide();
	       })
		},
		'History': {
			'Init':function(){
				if($(".vod_history").length){
	                var $that = $(".vod_history");
	                ShouTu.Mac.History.Set($that.attr('data-name'),$that.attr('data-link'),$that.attr('data-pic'),$that.attr('data-part'),$that.attr('data-limit'));
	            }
			},
			'Set':function(name,link,pic,part,limit){
				if(!link){ link = document.URL;}
				var history = ShouTu.Cookie.Get("history");
			    var len=0;
			    var canadd=true;
			    if(history){
			        history = eval("("+history+")"); 
			        len=history.length;
			        $(history).each(function(){
			            if(name==this.name){
			                canadd=false;
			                var json="[";
			                $(history).each(function(i){
			                    var temp_name,temp_img,temp_url,temp_part;
			                    if(this.name==name){
			                        temp_name=name;temp_img=pic;temp_url=link;temp_part=part;
			                    }else{
			                        temp_name=this.name;temp_img=this.pic;temp_url=this.link;temp_part=this.part;
			                    }
			                    json+="{\"name\":\""+temp_name+"\",\"pic\":\""+temp_img+"\",\"link\":\""+temp_url+"\",\"part\":\""+temp_part+"\"}";
			                    if(i!=len-1)
			                    json+=",";
			                })
			                json+="]";
			                ShouTu.Cookie.Set('history',json,365);
			                return false;
			            }
			        });
			    }
			    if(canadd){
			        var json="[";
			        var start=0;
			        var isfirst="]";
			        isfirst=!len?"]":",";
			        json+="{\"name\":\""+name+"\",\"pic\":\""+pic+"\",\"link\":\""+link+"\",\"part\":\""+part+"\"}"+isfirst;
			        if(len>limit-1)
		            	len-=1;
		        	for(i=0;i<len-1;i++){
		            	json+="{\"name\":\""+history[i].name+"\",\"pic\":\""+history[i].pic+"\",\"link\":\""+history[i].link+"\",\"part\":\""+history[i].part+"\"},";
		       	 	}
		        	if(len>0){
		            	json+="{\"name\":\""+history[len-1].name+"\",\"pic\":\""+history[len-1].pic+"\",\"link\":\""+history[len-1].link+"\",\"part\":\""+history[len-1].part+"\"}]";
		        	}
			        ShouTu.Cookie.Set('history',json,365);
			    }  
			}
		},
		'Player': function() {
			if($("#player-left").length){
				let PlayerLeft = $("#player-left");
		    	let PlayerSide = $("#player-sidebar");
				let OuterHeight = PlayerLeft.outerHeight()+20;
				let Position = $(".position-on li.active").position();
				if(OuterHeight>0){PlayerSide.css({"height":OuterHeight,"overflow":"auto"});}
				PlayerSide.scrollTop(Position.top);
			}
		},
		'Comment': {
			'Init':function(){
				$('body').on('click', '.comment-submit', function(e){			        
					if($(this).parent().parent().parent().find(".comment-data").val() == ''){
						ShouTu.Other.Toast('请输入评论内容',0,1000);
						return false;
					}
					ShouTu.Mac.Comment.Submit();
				});
				$('body').on('click', '.comment-report', function(e){
					var $that = $(this);
					if($(this).attr("data-id")){
						ShouTu.Ajax(maccms.path + '/index.php/comment/report.html?id='+$that.attr("data-id"),'get','json','',function(r){
							$that.addClass('disabled');                       
							ShouTu.Other.Toast(r.msg,1,1000);
						});
					}
				});
				$('body').on('click', '.comment-reply', function(e){
					var $that = $(this);
					if($that.attr("data-id")){
						var str = $that.html();
						$('.comment-reply-form').remove();
						if (str == '<i class="icon icon-news1"></i> 取消') {
							$that.html('<i class="icon icon-news1"></i> 回复');
							return false;
						}
						if (str == '回复') {
							$('.comment-reply').html('<i class="icon icon-news1"></i> 回复');
						}
						var html = $('.comment-form').prop("outerHTML");

						var oo = $(html);
						oo.addClass('comment-reply-form mt15').find(".btn").addClass("btn-mini");
						oo.find('input[name="comment_pid"]').val( $that.attr("data-id") );

						$that.parent().after(oo);
						$that.html('<i class="icon icon-news1"></i> 取消');
					}
				});
				$('body').on('click', '.comment-report', function(e){
					var $that = $(this);
					if($(this).attr("data-id")){
						ShouTu.Ajax(maccms.path + '/index.php/comment/report.html?id='+$that.attr("data-id"),'get','json','',function(r){
							$that.addClass('disabled');
							ShouTu.Other.Toast(r.msg,1,1000);
						});
					}
				});
			},
			'Show':function($page){
				ShouTu.Ajax(maccms.path + '/index.php/comment/ajax.html?rid='+$('.ShouTu_comment').attr('data-id')+'&mid='+ $('.ShouTu_comment').attr('data-mid') +'&page='+$page,'get','json','',function(r){
					$(".ShouTu_comment").html(r);
				},function(){
					$(".ShouTu_comment").html('<p class="text-center"><a href="javascript:void(0)" onclick="ShouTu.Comment.Show('+$page+');">评论加载失败，点击我刷新...</a></p>');
				});
			},
			'Submit':function(){		        
				ShouTu.Ajax(maccms.path + '/index.php/comment/saveData','post','json',$(".comment-form").serialize() + '&comment_mid='+ $('.ShouTu_comment').attr('data-mid') + '&comment_rid=' + $('.ShouTu_comment').attr('data-id'),function(r){
					if(r.code==1){
						ShouTu.Other.Toast(r.msg,1,1000);
						ShouTu.Mac.Comment.Show(1);
					} else {
						if(ShouTu.Mac.Gbook.Verify==1){
							ShouTu.Mac.Verify.Refresh();
						}
						ShouTu.Other.Toast(r.msg,0,1000);
					}
				});
			}
		},
		'Digg': {
			'Init':function(){
				$('body').on('click', '.support', function(e){
					let $that = $(this);
					if($that.attr("data-id")){
						ShouTu.Ajax(maccms.path + '/index.php/ajax/digg.html?mid='+$that.attr("data-mid")+'&id='+$that.attr("data-id")+'&type='+$that.attr("data-type"),'get','json','',function(r){
							$that.addClass('disabled');
							if(r.code == 1){
								if($that.attr("data-type")=='up'){
									$that.find('.digg_num').html(r.data.up);
									ShouTu.Other.Toast('感谢参与！',1,1000);
								}
								else{
									$that.find('.digg_num').html(r.data.down);
									ShouTu.Other.Toast('感谢参与！',1,1000);
								}
							}
							else{
								ShouTu.Other.Toast(r.msg,0,1000);
							}
						});
					}
				});
			}
		},
		'Gbook': {
			'Login':0,
        	'Verify':0,
			'Init':function(){
				$('body').on('keyup', '.gbook_content', function(e){
					ShouTu.Mac.Remaining($(this),200,'.gbook_remaining')
				});
				$('body').on('click', '.gbook_submit', function(e){
					if($(".gbook_data").val() == ''){
						ShouTu.Other.Toast('请输入内容',0,1000);
						return false;
					}
					if($(".verify_data").val() == ''){
						ShouTu.Other.Toast('请输入验证码',0,1000);
						return false;
					}
					ShouTu.Mac.Gbook.Submit();
				});
			},
			'Show':function($page){
				MAC.Ajax(maccms.path+'/index.php/gbook/index?page='+$page,'post','json','',function(r){
					$(".mac_gbook_box").html(r);
				},function(){
					$(".mac_gbook_box").html('留言加载失败，请刷新...');
				});
			},
			'Submit':function(){
				ShouTu.Ajax(maccms.path + '/index.php/gbook/saveData','post','json',$('.gbook_form').serialize(),function(r){
					if(r.code == 1){
						ShouTu.Other.Toast('留言成功',1,1000);
						location.reload();
					}
					else{
						if(ShouTu.Mac.Gbook.Verify==1){
							ShouTu.Mac.Verify.Refresh();
						}
						ShouTu.Other.Toast(r.msg,0,1000);
					}
				});
			}
		},
		'Verify': {
			'Init': function(){
				ShouTu.Mac.Verify.Focus();
				ShouTu.Mac.Verify.Click();
			},
			'Focus': function(){//验证码框焦点
				$('body').on("focus", ".mac_verify", function(){
					$(this).removeClass('mac_verify').after(ShouTu.Mac.Verify.Show());
					$(this).unbind();
				});
			},
			'Click': function(){//点击刷新
				$('body').on('click', 'img.mac_verify_img', function(){
					$(this).attr('src', maccms.path +'/index.php/verify/index.html?r='+Math.random());
				});
			},
			'Refresh':function(){
				$('.mac_verify_img').attr('src', maccms.path +'/index.php/verify/index.html?r='+Math.random());
			},
			'Show':function(){
				return '<img class="mac_verify_img" src="'+ maccms.path +'/index.php/verify/index.html?"  title="看不清楚? 换一张！">';
			}
		},
		'PageGo':{
			'Init':function() {
				$('.mac_page_go').click(function () {
					let that =$(this);
					let url = that.attr('data-url');
					let total = parseInt(that.attr('data-total'));
					let sp = that.attr('data-sp');
					let page= parseInt($('#page').val());
	
					if(page>0&&(page<=total)){
						url=url.replace(sp + 'PAGELINK',sp + page).replace('PAGELINK',page);
						location.href=url;
					}
					return false;
				});
			}
		},
		'Hits': {
			'Init':function() {
				if($('.mac_hits').length==0){
					return;
				}
				let $that = $(".mac_hits");
				ShouTu.Ajax(maccms.path + '/index.php/ajax/hits?mid='+$that.attr("data-mid")+'&id='+$that.attr("data-id")+'&type=update','get','json','',function(r){
					if (r.code == 1) {
						$(".mac_hits").each(function(i){
							$type = $(".mac_hits").eq(i).attr('data-type');
							if($type != 'insert'){
								$('.'+$type).html(eval('(r.data.' + $type + ')'));
							}
						});
					}
				});
	
			}
		},
		'Score':function(){
			let hadpingfen = 0;
			$("ul.rating li").each(function(i) {
				let $title = $(this).attr("title");
				let $lis = $("ul.rating li");
				let num = $(this).index();
				let n = num + 1;
				$(this).click(function () {
						if (hadpingfen > 0) {
							ShouTu.Other.Toast('请勿重复评分',0,1000);
						}
						else {
							$lis.removeClass("active");
							$("ul.rating li:lt(" + n + ")").find(".icon").addClass("icon-rating").removeClass("icon-rating-o");
							$("#ratewords").html($title);
							$.getJSON(maccms.path+'/index.php/ajax/score?mid='+$('#rating').attr('data-mid')+'&id='+$('#rating').attr('data-id')+'&score='+($(this).attr('val')*2), function (r) {
								if (parseInt(r.code) == 1) {
									ShouTu.Other.Toast(r.msg,1,1000);
									hadpingfen = 1;
								}
								else {
									hadpingfen = 1;
									ShouTu.Other.Toast(r.msg,0,1000);
								}
							});
						}
					}
				).hover(function () {
					this.myTitle = this.title;
					this.title = "";
					$(this).nextAll().find(".icon").addClass("icon-rating-o").removeClass("icon-rating");
					$(this).prevAll().find(".icon").addClass("icon-rating").removeClass("icon-rating-o");
					$(this).find(".icon").addClass("icon-rating").removeClass("icon-rating-o");
					$("#ratewords").html($title);
				}, function () {
					this.title = this.myTitle;
					$("ul.rating li:lt(" + n + ")").removeClass("hover");
				});
			});
		},
		'Autocomplete': function() {
			let searchWidth= $('#search').width();
			try {
				$('.search_wd').autocomplete(maccms.path + '/index.php/ajax/suggest?mid=1', {		
					resultsClass: "autocomplete-suggestions",
					width: searchWidth, scrollHeight: 410, minChars: 1, matchSubset: 0, cacheLength: 10, multiple: false, matchContains: true, autoFill: false,
					dataType: "json",
					parse: function (r) {
						if (r.code == 1) {
							$(".head-dropdown").hide();
							var parsed = [];
							$.each(r['list'], function (index, row) {
								row.url = r.url;
								parsed[index] = {
									data: row
								};
							});
							return parsed;
						} else {
							return {data: ''};
						}
					},
					formatItem: function (row, i, max) {
						return row.name;
					},
					formatResult: function (row, i, max) {
						return row.text;
					}
				}).result(function (event, data, formatted) {
					$(this).val(data.name);
					location.href = data.url.replace('mac_wd', encodeURIComponent(data.name));
				});
			}
			catch(e){}
		},
		'Favorite': function() {
			if($('.favorite').length>0){
				$('body').on('click', 'a.favorite', function(e){
					let $that = $(this);
					if($that.attr("data-id")){
						$.ajax({
							url: maccms.path+'/index.php/user/ajax_ulog/?ac=set&mid='+$that.attr("data-mid")+'&id='+$that.attr("data-id")+'&type='+$that.attr("data-type"),
							cache: false,
							dataType: 'json',
							success: function($r){
								ShouTu.Other.Toast(r.msg,1,1000);
							}
						});
					}
				});
			}
		},
		'Ulog':{
			'Init':function(){
				ShouTu.Mac.Ulog.Set();
				ShouTu.Mac.Ulog.Click();
	
			},
			'Get':function(mid,id,type,page,limit,call){
				MAC.Ajax(maccms.path+'/index.php/user/ajax_ulog/?ac=list&mid='+mid+'&id='+id+'&type='+type+'&page='+page+'&limit='+limit,'get','json','',call);
			},
			'Set':function(){
				if($(".mac_ulog_set").attr('data-mid')){
					let $that = $(".mac_ulog_set");
					$.get(maccms.path+'/index.php/user/ajax_ulog/?ac=set&mid='+$that.attr("data-mid")+'&id='+$that.attr("data-id")+'&sid='+$that.attr("data-sid")+'&nid='+$that.attr("data-nid")+'&type='+$that.attr("data-type"));
				}
			},
			'Click':function(){
				$('body').on('click', 'a.mac_ulog', function(e){
					//是否需要验证登录
					if(ShouTu.Mac.User.IsLogin == 0){
						ShouTu.Mac.User.Login();
						return;
					}
					let $that = $(this);
					if($that.attr("data-id")){
						ShouTu.Ajax(maccms.path+'/index.php/user/ajax_ulog/?ac=set&mid='+$that.attr("data-mid")+'&id='+$that.attr("data-id")+'&type='+$that.attr("data-type"),'get','json','',function(r){
							if(r.code == 1){
								$that.addClass('disabled');
							}else{
								ShouTu.Other.Toast(r.msg,0,1000);
							}
						});
					}
				});
			}
		},
		'Website':{
			'Referer':function() {
				if($('.mac_referer').length==0){
					return;
				}
	
				let url = document.referrer
					,domain=''
					,host = window.location.host
					,reg = /^http(s)?:\/\/(.*?)\//i
					,mc = url.match(reg);
	
				if(url=='' || url.indexOf(host)!=-1 || mc ==null){
					return;
				}
				domain = mc[2];
				ShouTu.Ajax(maccms.path + '/index.php/ajax/referer?domain='+encodeURIComponent(domain)+'&url='+encodeURIComponent(url)+'&type=update','get','json','',function(r){
					if (r.code == 1) {
					}
					console.log(r);
				});
			}
		},
		'User': {
			'BoxShow':0,
			'IsLogin':0,
			'UserId':'',
			'UserName':'',
			'GroupId':'',
			'GroupName':'',
			'Portrait':'',
			'Init':function(){
				if($('.mac_user').length >0){
					$('body').on('click', '.mac_user', function(e){
						ShouTu.Mac.User.Login();
					});

					$('.mac_user').hover(function(e){
						$('.mac_user_box').show();
					}, function(){
						$('.mac_user_box').hover(function(){
							ShouTu.Mac.User.BoxShow = 1;
						}, function(){
							ShouTu.Mac.User.BoxShow = 0;
							$('.mac_user_box').hide();
						});
					});
				}

				if(ShouTu.Cookie.Get('user_id') !=undefined && ShouTu.Cookie.Get('user_id')!=''){
					let url = maccms.path + '/index.php/user';
					ShouTu.Mac.User.UserId = ShouTu.Cookie.Get('user_id');
					ShouTu.Mac.User.UserName = ShouTu.Cookie.Get('user_name');
					ShouTu.Mac.User.GroupId = ShouTu.Cookie.Get('group_id');
					ShouTu.Mac.User.GroupName = ShouTu.Cookie.Get('group_name');
					ShouTu.Mac.User.Portrait = ShouTu.Cookie.Get('user_portrait');
					ShouTu.Mac.User.IsLogin = 1;
				}
			},
			'CheckLogin':function(){
				if(ShouTu.Mac.User.IsLogin == 0){
					ShouTu.Mac.User.Login();
				}
			},
			'Logout':function(){
				ShouTu.Ajax(maccms.path + '/index.php/user/logout','post','json','',function(r){
					ShouTu.Other.Toast(r.msg,1,1000);
					if(r.code == 1){
						location.reload();
					}
				});
			},
			'PopedomCallBack':function(trysee,h) {
				window.setTimeout(function(){
					$(window.frames["player_if"].document).find(".MacPlayer").html(h);
				},1000*10*trysee);
			},
			'BuyPopedom':function(o){
				let $that = $(o);
				if($that.attr("data-id")){
					if (confirm('您确认购买此条数据访问权限吗？')) {
						ShouTu.Ajax(maccms.path + '/index.php/user/ajax_buy_popedom.html?id=' + $that.attr("data-id") + '&mid=' + $that.attr("data-mid") + '&sid=' + $that.attr("data-sid") + '&nid=' + $that.attr("data-nid") + '&type=' + $that.attr("data-type"),'get','json','',function(r){
							$that.addClass('disabled');
							ShouTu.Other.Toast(r.msg,1,1000);
							if (r.code == 1) {
								top.location.reload();
							}
							$that.removeClass('disabled');
						});
					}
				}
			},
			'Login':function(){
				ShouTu.Layer.Div('.ajax_login');
				$('body').on('click', '.login_form_submit', function(e){
					$(this).unbind('click');
					ShouTu.Ajax(maccms.path + '/index.php/user/login','post','json',$('.mac_login_form').serialize(),function(r){
						ShouTu.Other.Toast(r.msg,1,1000);
						if(r.code == 1){
							ShouTu.Other.Toast(r.msg,1,1000);
							location.reload();
						}
					});
				});
			}
		},
		'Pwd':{
			'Check':function(o){
				let $that = $(o);
				if($that.attr("data-id")){
					ShouTu.Ajax(maccms.path + '/index.php/ajax/pwd.html?id=' + $that.attr("data-id") + '&mid=' + $that.attr("data-mid") + '&type=' + $that.attr("data-type") + '&pwd='+ $that.parents('form').find('input[name="pwd"]').val() ,'get','json','',function(r){
						$that.addClass('disabled');
						ShouTu.Other.Toast(r.msg,1,1000);
						if (r.code == 1) {
							location.reload();
						}
						$that.removeClass('disabled');
					});
	
				}
			}
		},
		'Remaining':function(obj,len,show){
			let count = len - $(obj).val().length;
			if(count < 0){
				count = 0;
				$(obj).val($(obj).val().substr(0,200));
			}
			$(show).text(count);
		},
		'Timming':function(){
			if($('.mac_timming').length==0){
				return;
			}
			var infile = $('.mac_timming').attr("data-file");
			if(infile==undefined || infile == ''){
				infile = 'api.php';
			}
			var t=(new Image());t.src=maccms.path + '/'+infile+'/timming/index?t='+Math.random();
		},
	}
};
$(function(){
	var $width = $(document).width();
	ShouTu.Swiper.Slide.Init();
	ShouTu.Swiper.Center.Init();
	ShouTu.Swiper.Left.Init();
	ShouTu.Swiper.Left2.Init();
	ShouTu.Images.Lazyload();
	ShouTu.Images.Qrcode.Init();
	ShouTu.Link.Copy.Init();
	ShouTu.Other.Nav();
	ShouTu.Other.Sort();
	ShouTu.Other.Skin.Init();
	ShouTu.Other.Search();
	ShouTu.Other.Collapse();
	ShouTu.Other.Slidedown();
	ShouTu.Other.Close();
	ShouTu.Other.More();
	ShouTu.Mac.Paylist();
	ShouTu.Mac.History.Init();
	ShouTu.Mac.Digg.Init();
	ShouTu.Mac.Comment.Init();
	ShouTu.Mac.Gbook.Init();
	ShouTu.Mac.Autocomplete();
	ShouTu.Mac.Favorite();
	ShouTu.Mac.Hits.Init();
	ShouTu.Mac.Score();
	ShouTu.Mac.Timming();
	if($width<=960){
		ShouTu.Swiper.Nav();
	}
	if($width>=960){
		ShouTu.Mac.Player();
	}
});
function shoutu_dialog($name){
	ShouTu.Other.Dialog('Dialog'+$name);
}
function shoutu_skin(){
	ShouTu.Other.Skin.Set();
}
function shoutu_scroll($id){
	ShouTu.Other.Scroll($id);
}